<td valign="top" height="700" width="20%" bgcolor="#fffacd">
<br>
             <h5>user: <?php echo $_SESSION['user']?><br>
             <hr>
             <a href="./user_page.php">รายการโทรศัพท์</a><br>
             <a href="./mblist.php">รายการจองโทรศัพท์</a><br>
             <hr>
             <a href="./Login.php">ออกจากระบบ</a><br>
            </td>
</h5>
            <td valign="top">
