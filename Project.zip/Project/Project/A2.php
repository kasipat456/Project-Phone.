<td valign="top" height="700" width="20%" bgcolor="#fffacd" >
<br>
            <h5>admim: <?php echo $_SESSION['user']?><br>
<hr>          
             <a href="./admim_page.php">เช็คสมาชิก</a><br>
             <a href="./stock.php">จัดการรายการสินค้า</a><br>
             <a href="./mbstock.php">รายการสั่งซื้อ</a><br>
             
<hr>

             <a href="./login.php">ออกจากระบบ</a><br>
            </td>
            </h5>
            <td valign="top"  >
