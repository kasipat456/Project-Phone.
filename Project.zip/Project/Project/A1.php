<DOCTYPE html>
<html>
    <head><title>ระบบจองโทรศัพท์</title>
    <meta charset="utf-8">
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

    <table boder="1" align="center" width="100%">
        <tr>
            <td valign="top" height="100" colspan="2">
            <img src="./image/mobiles-phones-banner.png" width="100%" height="200">
            </td>    
        </tr>
        <tr>
<style>
        
table {
  font-family: arial, sans-serif;
  /*border-collapse: collapse;*/
  text-align: center;
  margin: auto;
  
}
tr {
 background-color: #F5EED8; 
 
border: 5px solid rgba(0, 0, 0, .3);
} 
.tc{
  text-align: center;
}
.wt{
  width: 90%;
}

</style>
