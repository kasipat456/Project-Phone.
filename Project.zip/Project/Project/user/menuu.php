<td valign="top" height="700" width="20%" bgcolor="#778ca3">
<br>
             <h2>เมนู<br>
             <a href="./ex3.php">จองโทรศัพท์</a><br>
             <a href="./Loging.php">ออกจาระบบ</a><br>
            </td>
            <h2>
            <td valign="top">
