<DOCTYPE html>
<html>
    <head><title>ระบบจองโทรศัพท์</title></head>
<body>
    <table boder="1" align="center" width="100%">
        <tr>
            <td valign="top" height="100" colspan="2">
            <img src="./image/Untitled1.jpg" width="102%" height="200">
            </td>    
        </tr>
        <tr>