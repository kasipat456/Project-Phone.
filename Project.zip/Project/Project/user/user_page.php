<?php

   session_start();
   if (!$_SESSION['userid']) {
       header("Location: index.php");
   } else {

   }
?>
<!DOCTYPE html>
<html jand = "en">
<head>
    <meta charset ="UTF-8">
    <meta name="viewport" content= "width =device-width, initial-scale=1.0">


</html>
<?php ?>