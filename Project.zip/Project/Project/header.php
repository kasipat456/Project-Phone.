<DOCTYPE html>
<html>
    <head><title>ระบบจองโทรศัพท์</title></head>
<body>
    <table boder="1" align="center" width="100%">
        <tr>
            <td valign="top" height="100" colspan="2">
            <img src="./image/mobiles-phones-banner.png" width="100%" height="200">
            </td>    
        </tr>
        <tr>
        <style>
        td, th {
  border: 4px solid #000000;
}
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  text-align: center;
 
}
tr:nth-child(even) {
 background-color: #F5EED8;
 width: 100%;

}  
</style>